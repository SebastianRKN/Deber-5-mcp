# MCP Detective

## 1. Arquitectura

El LLM eligió qué herramienta llamar y con qué argumentos. Luego interpretó los eventos y justificó la alerta. Codex fue el host que coordinó la interacción y puso las herramientas a disposición del modelo. Su cliente MCP descubrió las herramientas, envió las llamadas por `stdio` y devolvió sus resultados al host. El intérprete de Python ejecutó `server.py` en el proceso del servidor MCP. Ese servidor leyó los datos, validó las entradas y guardó la alerta en memoria.

## 2. Evidencia

En `INC-003`, la cuenta `admin` tuvo cuatro fallos entre las 03:00 y las 03:03 y un inicio de sesión exitoso a las 03:04. Los cinco eventos vinieron de `192.0.2.50` y ocurrieron en el panel de administración. Registré una alerta de nivel alto por la secuencia y los privilegios de la cuenta. El registro indica que hubo un acceso exitoso, pero no identifica quién estaba detrás ni permite saber si tenía autorización.

## 3. Validación y seguridad

El servidor rechaza `INC-999`, los niveles inválidos, los motivos en blanco y las alertas duplicadas. La lógica genera `ValueError` y las herramientas lo traducen a `ToolError` para que el SDK v2 comunique el motivo al cliente. El modelo puede proponer argumentos equivocados. El servidor comprueba cada llamada antes de guardar una alerta y garantiza que solo haya una por caso en cada proceso.

## Instalación y verificación

Desde la raíz del repositorio, con Python 3.11 o superior y Node.js con `npx`:

```bash
python -m pip install "mcp[cli]==2.3.0" pytest
python -m pytest mcp-detective -q
mcp dev mcp-detective/server.py
```

En el Inspector, conecta el servidor por `stdio`, descubre las tres herramientas y ejecuta D1–D7. Repite el registro válido en el mismo proceso para observar el rechazo. Cierra la conexión al servidor y vuelve a abrirla para iniciar un proceso nuevo. El mismo registro vuelve a funcionar.

Usé Codex CLI en una sesión nueva. Para conectarlo, sustituye las rutas de ejemplo por las rutas absolutas al Python que tiene instalado el SDK y al archivo `server.py`.

```powershell
codex mcp add centinela -- "C:\ruta\al\entorno\Scripts\python.exe" "C:\ruta\al\repo\mcp-detective\server.py"
```

Inicia una sesión nueva y aprueba las llamadas solicitadas al servidor local. Comprobé la conexión en la salida JSON de `codex exec` con las llamadas a `centinela`, sus argumentos y los resultados. En esa sesión, Codex obtuvo los eventos por MCP, registró la alerta y recibió el error de `INC-999`.

Las imágenes en `evidencias/` reproducen el código y las salidas reales. Las pruebas del Inspector se ejecutaron mediante su interfaz HTTP local, con el servidor conectado por `stdio`. La evidencia del agente presenta la traza de la CLI en formato legible.
